﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 FilesystemMonitorClient.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FILESYSTEMMONITORCLIENT_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_SHELL_DIALOG                131
#define IDR_MENU2                       133
#define IDC_LIST_RECORD                 1002
#define IDC_EDIT_RULE                   1003
#define IDC_LIST_RULES                  1004
#define IDC_STATIC_TITLE                1005
#define IDC_STATIC_NEW                  1006
#define IDC_EDIT_TITLE                  1007
#define IDC_BUTTON_REFRESH              1008
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_32776                        32776
#define ID_Menu                         32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_32780                        32780
#define ID_OPEN                         32781
#define ID_SAVE                         32782
#define ID_PRINT                        32783
#define ID_EXIT                         32784
#define ID_STOP                         32785
#define ID_SHELL                        32786
#define ID_CLEAR                        32787
#define ID_Menu32788                    32788
#define ID_ABOUT                        32789
#define ID_32790                        32790
#define ID_START                        32791
#define ID_LINK_32792                   32792
#define ID_LINK_32793                   32793
#define ID_LINK_32794                   32794
#define ID_LINK_DETAIL                  32795
#define ID_LINK_MODIFY                  32796
#define ID_LINK_DELETE                  32797

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32798
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
